import { Controls } from './controls';

describe('Controls', () => {
  it('should create an instance', () => {
    expect(new Controls()).toBeTruthy();
  });
});
