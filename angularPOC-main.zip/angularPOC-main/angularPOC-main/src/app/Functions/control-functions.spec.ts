import { ControlFunctions } from './control-functions';

describe('ControlFunctions', () => {
  it('should create an instance', () => {
    expect(new ControlFunctions()).toBeTruthy();
  });
});
