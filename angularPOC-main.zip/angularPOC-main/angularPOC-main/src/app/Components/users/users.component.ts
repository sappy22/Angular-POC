import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  userInformation = [
    { name: "Anthony", age: 30 },
    { name: "Vikram", age: 20 },
    { name: "Deepak", age: 16 },
    { name: "Raja", age: 12 },
    { name: "Amit", age: 35 },

  ];

  toggle: boolean = false;

  constructor() { }

  ngOnInit() {
  }

  toggleValue() {
    this.toggle = !this.toggle;
  }
}
