# angularPOC

Angular POC
Angular poc 1 URL: http://localhost:4200/users
Angular poc 2 URL: http://localhost:4200/well/list
Angular poc 3 URL: http://localhost:4200/controls
